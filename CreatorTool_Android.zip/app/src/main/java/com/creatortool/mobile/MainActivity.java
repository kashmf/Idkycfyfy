package com.creatortool.mobile;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Runs the Creator Tool directly from packaged app assets.
 * The virtual HTTPS origin is intercepted by WebViewClient; no TCP server is
 * started and no web hosting is required.
 */
public class MainActivity extends Activity {
    private static final String TAG = "CreatorTool";
    private static final String LOCAL_HOST = "creator-tool.local";
    private static final String START_URL = "https://" + LOCAL_HOST + "/";
    private static final int FILE_CHOOSER_REQUEST = 4102;

    private WebView webView;
    private ValueCallback<Uri[]> pendingFileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(24, 27, 32));
        window.setNavigationBarColor(Color.rgb(18, 20, 24));
        window.getDecorView().setSystemUiVisibility(0);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(24, 27, 32));
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }

        webView.addJavascriptInterface(new NativeBridge(), "CreatorToolNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (LOCAL_HOST.equalsIgnoreCase(uri.getHost())) {
                    return serveLocalAsset(uri.getPath(), request.getRequestHeaders());
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (LOCAL_HOST.equalsIgnoreCase(uri.getHost())) return false;
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
                if ("https".equals(scheme) || "http".equals(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException ignored) {
                        Toast.makeText(MainActivity.this, "No browser is available for this link", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                installDownloadBridge();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
                pendingFileCallback = filePathCallback;
                openDocumentPicker(fileChooserParams);
                return true;
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage message) {
                Log.d(TAG, message.message() + " (" + message.sourceId() + ":" + message.lineNumber() + ")");
                return true;
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            // Normal network downloads are handed to the Android browser.
            // Blob downloads are handled by the in-page JavaScript bridge below.
            try {
                Uri uri = Uri.parse(url);
                if ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme())) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                }
            } catch (Exception e) {
                Log.w(TAG, "Could not open download URL", e);
            }
        });

        webView.loadUrl(START_URL);
    }

    private WebResourceResponse serveLocalAsset(String requestPath, Map<String, String> requestHeaders) {
        try {
            String decoded = URLDecoder.decode(requestPath == null ? "/" : requestPath, "UTF-8");
            if (decoded.isEmpty() || "/".equals(decoded)) decoded = "/index.html";
            while (decoded.startsWith("/")) decoded = decoded.substring(1);
            if (decoded.contains("..") || decoded.contains("\\")) return notFound();

            String assetPath = "CreatorTool_web/" + decoded;
            byte[] bytes;
            try (InputStream in = getAssets().open(assetPath);
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[16 * 1024];
                int read;
                while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                bytes = out.toByteArray();
            }

            String mime = mimeType(decoded);
            Map<String, String> headers = new HashMap<>();
            headers.put("Access-Control-Allow-Origin", "https://" + LOCAL_HOST);
            headers.put("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
            headers.put("Access-Control-Allow-Headers", "Content-Type, Range");
            headers.put("Accept-Ranges", "bytes");
            headers.put("Cache-Control", "public, max-age=86400");

            String range = findHeader(requestHeaders, "Range");
            if (range != null && range.startsWith("bytes=")) {
                long[] bounds = parseRange(range, bytes.length);
                if (bounds != null) {
                    int start = (int) bounds[0];
                    int end = (int) bounds[1];
                    byte[] part = Arrays.copyOfRange(bytes, start, end + 1);
                    headers.put("Content-Range", "bytes " + start + "-" + end + "/" + bytes.length);
                    headers.put("Content-Length", String.valueOf(part.length));
                    return new WebResourceResponse(mime, null, 206, "Partial Content", headers,
                            new ByteArrayInputStream(part));
                }
            }
            headers.put("Content-Length", String.valueOf(bytes.length));
            return new WebResourceResponse(mime, charsetFor(mime), 200, "OK", headers,
                    new ByteArrayInputStream(bytes));
        } catch (Exception e) {
            Log.w(TAG, "Asset not found: " + requestPath, e);
            return notFound();
        }
    }

    private WebResourceResponse notFound() {
        Map<String, String> headers = new HashMap<>();
        headers.put("Cache-Control", "no-store");
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", headers,
                new ByteArrayInputStream("Not found".getBytes(StandardCharsets.UTF_8)));
    }

    private static String findHeader(Map<String, String> headers, String name) {
        if (headers == null) return null;
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            if (name.equalsIgnoreCase(entry.getKey())) return entry.getValue();
        }
        return null;
    }

    private static long[] parseRange(String range, int length) {
        try {
            String value = range.substring("bytes=".length()).trim();
            String[] parts = value.split("-", 2);
            long start = Long.parseLong(parts[0]);
            long end = parts.length > 1 && !parts[1].isEmpty() ? Long.parseLong(parts[1]) : length - 1L;
            if (start < 0 || start >= length || end < start) return null;
            end = Math.min(end, length - 1L);
            return new long[]{start, end};
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String mimeType(String path) {
        String lower = path.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".html")) return "text/html";
        if (lower.endsWith(".js")) return "text/javascript";
        if (lower.endsWith(".css")) return "text/css";
        if (lower.endsWith(".json")) return "application/json";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".webp")) return "image/webp";
        if (lower.endsWith(".ogg")) return "audio/ogg";
        if (lower.endsWith(".mp3")) return "audio/mpeg";
        if (lower.endsWith(".wav")) return "audio/wav";
        if (lower.endsWith(".ttf")) return "font/ttf";
        if (lower.endsWith(".otf")) return "font/otf";
        if (lower.endsWith(".woff2")) return "font/woff2";
        if (lower.endsWith(".woff")) return "font/woff";
        if (lower.endsWith(".wasm")) return "application/wasm";
        String ext = lower.contains(".") ? lower.substring(lower.lastIndexOf('.') + 1) : "";
        String guess = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return guess == null ? "application/octet-stream" : guess;
    }

    private static String charsetFor(String mime) {
        if (mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json")) return "UTF-8";
        return null;
    }

    private void openDocumentPicker(WebChromeClient.FileChooserParams params) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        String[] accept = params == null ? null : params.getAcceptTypes();
        if (accept != null && accept.length > 0) {
            ArrayList<String> mimeTypes = new ArrayList<>();
            for (String item : accept) {
                if (item == null || item.trim().isEmpty()) continue;
                String value = item.trim();
                if (value.startsWith(".")) {
                    String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(value.substring(1));
                    if (mime != null) mimeTypes.add(mime);
                } else if (value.contains("/")) {
                    mimeTypes.add(value);
                }
            }
            if (!mimeTypes.isEmpty()) intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes.toArray(new String[0]));
        }
        boolean multiple = params != null && params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE;
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);
        try {
            startActivityForResult(intent, FILE_CHOOSER_REQUEST);
        } catch (ActivityNotFoundException e) {
            if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
            pendingFileCallback = null;
            Toast.makeText(this, "No file picker is available", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST) return;
        if (pendingFileCallback == null) return;
        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                results = new Uri[count];
                for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
        }
        pendingFileCallback.onReceiveValue(results);
        pendingFileCallback = null;
    }

    private void installDownloadBridge() {
        String script = "(function(){if(window.__creatorToolDownloadHook)return;window.__creatorToolDownloadHook=true;" +
                "document.addEventListener('click',function(ev){var el=ev.target;var a=el&&el.closest?el.closest('a[download]'):null;" +
                "if(!a||!a.href||!a.href.startsWith('blob:'))return;ev.preventDefault();ev.stopImmediatePropagation();" +
                "var name=a.getAttribute('download')||'CreatorTool-export';fetch(a.href).then(function(r){return r.blob()}).then(function(blob){" +
                "var reader=new FileReader();reader.onload=function(){try{CreatorToolNative.saveDataUrl(reader.result,String(name),blob.type||'application/octet-stream')}catch(e){console.error(e)}};" +
                "reader.readAsDataURL(blob)}).catch(function(e){console.error('Export failed',e)})},true)})();";
        webView.evaluateJavascript(script, null);
    }

    private class NativeBridge {
        @JavascriptInterface
        public void saveDataUrl(String dataUrl, String fileName, String mimeType) {
            try {
                int comma = dataUrl.indexOf(',');
                if (comma < 0) throw new IllegalArgumentException("Invalid file data");
                byte[] data = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
                String safeName = fileName == null ? "CreatorTool-export" : fileName.replaceAll("[\\\\/:*?\"<>|]", "_");
                if (safeName.trim().isEmpty()) safeName = "CreatorTool-export";
                Uri savedUri = null;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
                    values.put(MediaStore.MediaColumns.MIME_TYPE,
                            mimeType == null || mimeType.isEmpty() ? "application/octet-stream" : mimeType);
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Creator Tool");
                    values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                    savedUri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (savedUri == null) throw new IllegalStateException("Could not create Downloads file");
                    try (OutputStream output = getContentResolver().openOutputStream(savedUri)) {
                        if (output == null) throw new IllegalStateException("Could not open Downloads file");
                        output.write(data);
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(savedUri, done, null, null);
                } else {
                    File folder = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Creator Tool");
                    if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Could not create export folder");
                    File file = new File(folder, safeName);
                    try (FileOutputStream output = new FileOutputStream(file)) { output.write(data); }
                }
                final String message = "Saved " + safeName + " to Downloads/Creator Tool";
                runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                Log.e(TAG, "Export failed", e);
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Export failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (pendingFileCallback != null) {
            pendingFileCallback.onReceiveValue(null);
            pendingFileCallback = null;
        }
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
