(() => {
  const controls = [
    ['up', '▲', 'ArrowUp'],
    ['left', '◀', 'ArrowLeft'],
    ['down', '▼', 'ArrowDown'],
    ['right', '▶', 'ArrowRight'],
    ['dash', '◆', 'Space']
  ];

  function keyEvent(type, code) {
    window.dispatchEvent(new KeyboardEvent(type, {
      key: code === 'Space' ? ' ' : code.replace('Arrow', ''),
      code,
      bubbles: true,
      cancelable: true
    }));
  }

  function makeButton(id, label, code) {
    const b = document.createElement('button');
    b.className = `mobile-control mobile-control-${id}`;
    b.type = 'button';
    b.setAttribute('aria-label', id === 'dash' ? 'Dash' : id);
    b.textContent = label;
    b.dataset.code = code;

    const press = (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (b.dataset.held === '1') return;
      b.dataset.held = '1';
      b.classList.add('pressed');
      keyEvent('keydown', code);
    };
    const release = (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (b.dataset.held !== '1') return;
      b.dataset.held = '0';
      b.classList.remove('pressed');
      keyEvent('keyup', code);
    };

    b.addEventListener('pointerdown', press, { passive: false });
    b.addEventListener('pointerup', release, { passive: false });
    b.addEventListener('pointercancel', release, { passive: false });
    b.addEventListener('pointerleave', release, { passive: false });
    b.addEventListener('contextmenu', e => e.preventDefault());
    return b;
  }

  function install() {
    if (document.getElementById('mobile-controls')) return;
    const root = document.createElement('div');
    root.id = 'mobile-controls';
    root.setAttribute('aria-label', 'Touch controls');

    const dpad = document.createElement('div');
    dpad.className = 'mobile-dpad';
    for (const [id, label, code] of controls.slice(0, 4)) dpad.appendChild(makeButton(id, label, code));

    const dash = makeButton(...controls[4]);
    const hint = document.createElement('div');
    hint.className = 'mobile-controls-hint';
    hint.textContent = 'TOUCH CONTROLS';

    root.append(dpad, dash, hint);
    document.body.appendChild(root);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', install, { once: true });
  else install();
})();
