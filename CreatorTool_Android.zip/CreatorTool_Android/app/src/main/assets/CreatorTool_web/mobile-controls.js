(() => {
  const KEY_CODES = {
    up: 'ArrowUp',
    down: 'ArrowDown',
    left: 'ArrowLeft',
    right: 'ArrowRight',
    dash: 'Space'
  };

  function keyEvent(type, code) {
    window.dispatchEvent(new KeyboardEvent(type, {
      key: code === 'Space' ? ' ' : code.replace('Arrow', ''),
      code,
      bubbles: true,
      cancelable: true
    }));
  }

  function makeDashButton() {
    const b = document.createElement('button');
    b.className = 'mobile-control mobile-control-dash';
    b.type = 'button';
    b.setAttribute('aria-label', 'Dash');
    b.textContent = '◆';

    const press = (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (b.dataset.held === '1') return;
      b.dataset.held = '1';
      b.classList.add('pressed');
      keyEvent('keydown', KEY_CODES.dash);
    };

    const release = (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (b.dataset.held !== '1') return;
      b.dataset.held = '0';
      b.classList.remove('pressed');
      keyEvent('keyup', KEY_CODES.dash);
    };

    b.addEventListener('pointerdown', press, { passive: false });
    b.addEventListener('pointerup', release, { passive: false });
    b.addEventListener('pointercancel', release, { passive: false });
    b.addEventListener('pointerleave', release, { passive: false });
    b.addEventListener('contextmenu', e => e.preventDefault());
    return b;
  }

  function makeJoystick() {
    const base = document.createElement('div');
    base.className = 'mobile-joystick';
    base.setAttribute('aria-label', 'Movement joystick');

    const ring = document.createElement('div');
    ring.className = 'mobile-joystick-ring';

    const knob = document.createElement('div');
    knob.className = 'mobile-joystick-knob';

    const center = document.createElement('div');
    center.className = 'mobile-joystick-center';

    base.append(ring, center, knob);

    const active = new Set();
    let pointerId = null;
    let centerX = 0;
    let centerY = 0;
    const maxDistance = 48;
    const deadZone = 13;

    function setKey(direction, pressed) {
      const code = KEY_CODES[direction];
      if (!code) return;

      if (pressed && !active.has(direction)) {
        active.add(direction);
        keyEvent('keydown', code);
      } else if (!pressed && active.has(direction)) {
        active.delete(direction);
        keyEvent('keyup', code);
      }
    }

    function releaseAll() {
      for (const direction of ['up', 'down', 'left', 'right']) {
        setKey(direction, false);
      }
      knob.style.transform = 'translate(-50%, -50%)';
    }

    function updateJoystick(clientX, clientY) {
      let dx = clientX - centerX;
      let dy = clientY - centerY;
      const distance = Math.hypot(dx, dy);

      if (distance > maxDistance) {
        const scale = maxDistance / distance;
        dx *= scale;
        dy *= scale;
      }

      knob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;

      if (distance < deadZone) {
        releaseAll();
        return;
      }

      // Use the same four keyboard directions the original controls used.
      // Diagonal movement is supported when the stick is between axes.
      const normalizedX = dx / maxDistance;
      const normalizedY = dy / maxDistance;
      const horizontal = Math.abs(normalizedX) > 0.35;
      const vertical = Math.abs(normalizedY) > 0.35;

      setKey('left', horizontal && normalizedX < 0);
      setKey('right', horizontal && normalizedX > 0);
      setKey('up', vertical && normalizedY < 0);
      setKey('down', vertical && normalizedY > 0);
    }

    function start(e) {
      if (pointerId !== null) return;
      e.preventDefault();
      e.stopPropagation();
      pointerId = e.pointerId;
      base.setPointerCapture?.(pointerId);
      const rect = base.getBoundingClientRect();
      centerX = rect.left + rect.width / 2;
      centerY = rect.top + rect.height / 2;
      base.classList.add('active');
      updateJoystick(e.clientX, e.clientY);
    }

    function move(e) {
      if (e.pointerId !== pointerId) return;
      e.preventDefault();
      e.stopPropagation();
      updateJoystick(e.clientX, e.clientY);
    }

    function end(e) {
      if (e.pointerId !== pointerId) return;
      e.preventDefault();
      e.stopPropagation();
      releaseAll();
      pointerId = null;
      base.classList.remove('active');
      try { base.releasePointerCapture?.(e.pointerId); } catch (_) {}
    }

    base.addEventListener('pointerdown', start, { passive: false });
    base.addEventListener('pointermove', move, { passive: false });
    base.addEventListener('pointerup', end, { passive: false });
    base.addEventListener('pointercancel', end, { passive: false });
    base.addEventListener('lostpointercapture', () => {
      if (pointerId !== null) {
        releaseAll();
        pointerId = null;
        base.classList.remove('active');
      }
    });
    base.addEventListener('contextmenu', e => e.preventDefault());

    return base;
  }

  function install() {
    if (document.getElementById('mobile-controls')) return;

    const root = document.createElement('div');
    root.id = 'mobile-controls';
    root.setAttribute('aria-label', 'Touch controls');

    const joystick = makeJoystick();
    const dash = makeDashButton();
    const hint = document.createElement('div');
    hint.className = 'mobile-controls-hint';
    hint.textContent = 'TOUCH CONTROLS';

    root.append(joystick, dash, hint);
    document.body.appendChild(root);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', install, { once: true });
  } else {
    install();
  }
})();
