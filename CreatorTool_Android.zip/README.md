# Creator Tool — Android app wrapper

This project packages the supplied Creator Tool mobile build inside an Android WebView. The HTML, JavaScript modules, CSS, images, fonts, and audio are stored in the APK itself.

**At runtime it does not start Python, Termux, a TCP server, or an internet-hosted website.** The app maps a private virtual HTTPS origin (`https://creator-tool.local/`) to its packaged assets through Android WebView request interception. Nothing is listening on a network port.

## Build an APK

You need Android Studio installed on a computer for the easiest build:

1. Extract this ZIP.
2. Open the extracted `CreatorTool_Android` folder in Android Studio.
3. Let Android Studio sync the Gradle project and install Android SDK Platform 35 if prompted.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Install the generated debug APK from `app/build/outputs/apk/debug/app-debug.apk` on your Android phone.

The project uses Java 17, Android Gradle Plugin 8.7.3, compile SDK 35, and minimum Android 6.0 (API 23).

## Build without Android Studio (GitHub Actions)

The included workflow at `.github/workflows/android.yml` can build the debug APK after this folder is uploaded to a GitHub repository. Open the repository's **Actions** tab and run **Build Android APK**. The APK is uploaded as an artifact named `creator-tool-debug-apk`.

## Mobile support included

The packaged web build includes the responsive mobile stylesheet and on-screen directional / dash controls from the supplied `CreatorTool_mobile_controls.zip`.

The Android wrapper also provides:

- Android document picker support for importing files.
- Saving exported files into `Downloads/Creator Tool` on Android 10 and newer.
- Hardware-accelerated WebView rendering and media playback.
- Local bundled asset loading with a secure virtual HTTPS origin.

## Important limitation

This is an **Android Studio project**, not a precompiled APK. It must be built once to produce an installable APK. I could not compile the APK in this environment because the Android SDK / Android build tools are not installed here.
